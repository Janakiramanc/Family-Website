var conf = require('./config.json'); // To main the script and sass files seperately
var gulp = require('gulp'); // gulp runner

var sass = require('gulp-sass'); // sass file converting into css
var browserSync = require('browser-sync').create(); // browser sycing project


function styles() {
    return gulp.src(conf.src.sass + '/*.scss')
    .pipe(sass())
    .pipe(gulp.dest(conf.dest.css))
    .pipe(browserSync.stream());
};

function htmlWatch() {
    return gulp.src('index.html')
    .pipe(browserSync.stream());
};


function serve(done) {
    browserSync.init({
        browser: "chrome",
    server: {
        baseDir: "./",
        proxy: "localhost",
        index: "index.html"
    }
    });
    done();
};
function reload(done) {
    browserSync.reload();
    done();
}
function watch(){
    gulp.watch(conf.src.sass + '/*.scss', gulp.series(styles, reload));
    gulp.watch('index.html', gulp.series(htmlWatch, reload));
}

gulp.task('default', gulp.parallel( htmlWatch, styles, serve, watch)); 
